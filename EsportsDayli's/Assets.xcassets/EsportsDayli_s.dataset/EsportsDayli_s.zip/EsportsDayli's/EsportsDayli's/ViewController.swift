//
//  ViewController.swift
//  EsportsDayli's
//
//  Created by Apps2m on 21/01/2021.
//  Copyright © 2021 Apps2m. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

